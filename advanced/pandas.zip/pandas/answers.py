import pandas as pd
from numpy import nan

def test_melt(melted_sales):
    solution = pd.DataFrame({
        'Month': ['Jan', 'Feb', 'Mar', 'Jan', 'Feb', 'Mar', 'Jan', 'Feb', 'Mar'],
        'Product': ['Electronics', 'Electronics', 'Electronics', 'Clothing', 'Clothing', 'Clothing', 'Books', 'Books', 'Books'],
        'Sales': [120, 150, 180, 80, 90, 100, 30, 40, 50]
    })
    print("Testing: ", end='')
    pd.testing.assert_frame_equal(melted_sales, solution)
    print('Success!')


def test_pivot(pivot_grades):
    solution = pd.DataFrame([[8.0, nan],
                      [5.5, 3.5],
                      [nan, 7.0],
                      [6.5, nan],
                      [9.5, 9.0]],
                      columns=['Programming 1', 'Programming 2'],
                      index=['Marge', 'Morty', 'Pascal', 'Slartibartfast', 'Ursula'])
    print("Testing: ", end='')
    pd.testing.assert_frame_equal(pivot_grades, solution, check_names=False)
    print('Success!')

def test_pivot_table(pivot_temperatures):
    solution = pd.DataFrame([[30, 25], [25, 22]], columns=['Breda', 'De Bilt'], index=['2023-01-01', '2023-01-02'])
    print("Testing: ", end='')
    pd.testing.assert_frame_equal(pivot_temperatures, solution, check_names=False)
    print('Success!')

def test_explode(exploded_actors):
    solution = pd.DataFrame({
        'movie': ['Hababam Sinifi', 'Hababam Sinifi', 'Hababam Sinifi', 'Hababam Sinifi',
                  'The Shawshank Redemption', 'The Shawshank Redemption', 'The Shawshank Redemption', 'The Shawshank Redemption',
                  'Aynabaji', 'Aynabaji', 'Aynabaji', 'Aynabaji',
                  'The Godfather', 'The Godfather', 'The Godfather', 'The Godfather'],
        'actors': ['Kemal Sunal', 'Münir Özkul', 'Halit Akçatepe', 'Tarik Akan',
                   'Tim Robbins', 'Morgan Freeman', 'Bob Gunton', 'William Sadler',
                   'Chanchal Chowdhury', 'Masuma Rahman Nabila', 'Bijori Barkatullah', 'Partha Barua',
                   'Marlon Brando', 'Al Pacino', 'James Caan', 'Diane Keaton']
    }, index=[0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3])
    print("Testing: ", end='')
    pd.testing.assert_frame_equal(exploded_actors, solution, check_names=False)
    print('Success!')

def test_final():
    print("Testing: ", end='')

    student_solution = pd.read_csv('data/ingredients.csv').sort_values(['ingredients', 'recipe_name']).reset_index(drop=True)
    solution = pd.read_csv('data/ingredients_solution.csv').sort_values(['ingredients', 'recipe_name']).reset_index(drop=True)

    pd.testing.assert_frame_equal(student_solution, solution)
    print('Success!')
